//package com.candiolli;
//
//import io.quarkus.test.junit.QuarkusIntegrationTest;
//
//@QuarkusIntegrationTest
//public class GreetingControllerIT extends GreetingControllerTest {
//    // Execute the same tests but in packaged mode.
//}
