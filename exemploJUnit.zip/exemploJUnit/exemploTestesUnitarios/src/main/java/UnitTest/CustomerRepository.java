package UnitTest;

public class CustomerRepository {

    public Customer save(Customer customer) {
        return customer;
    }

}
