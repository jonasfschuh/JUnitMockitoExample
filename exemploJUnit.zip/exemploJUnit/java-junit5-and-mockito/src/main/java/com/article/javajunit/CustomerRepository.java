package com.article.javajunit;

public class CustomerRepository {

    public Customer save(Customer customer) {
        return customer;
    }

}
