package com.article.javajunit;

public class InvalidValueException extends Exception {
    public InvalidValueException(String message) {
        super(message);
    }
}
